import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from '../services/apiservice.service';

@Component({
  selector: 'app-tableview',
  templateUrl: './tableview.component.html',
  styleUrls: ['./tableview.component.css'],
  providers:[ApiserviceService]
})
export class TableviewComponent implements OnInit {

  data:any;
  filteredDistricts: any; 
  

  constructor(private apiservice:ApiserviceService){
    
  }

  ngOnInit(): void {
    this.getData()
    
    
  }


  getData(){
    this.apiservice.getmedData().subscribe((d:any)=>{
        this.data=d
        console.log(this.data)
        this.filteredDistricts = Object.keys(this.data.summary).map((key) => ({
          name: key,
          details: this.data.summary[key],
        }));
        if (this.filteredDistricts) {
          localStorage.setItem('summary',JSON.stringify(this.filteredDistricts) )        }
        
    })
   

  
}


    // filterdistrict(){    
    //     this.filteredDistricts = Object.keys(this.data.summary).map((key) => ({
    //       name: key,
    //       details: this.data.summary[key],
    //     }));

    //     console.log(this.filteredDistricts)
    //   }
    
}
