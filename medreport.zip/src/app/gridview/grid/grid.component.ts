import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from 'src/app/services/apiservice.service';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.css'],
  providers:[ApiserviceService]
})
export class GridComponent implements OnInit {



  filtereddata:any=localStorage.getItem('summary')

  summarydata:any

  

  ngOnInit(): void {
      if (this.filtereddata) {
        this.summarydata=JSON.parse(this.filtereddata)        
      }
      console.log(this.summarydata)
  }

 

}
