import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser'

import { GridviewRoutingModule } from './gridview-routing.module';
import { GridComponent } from './grid/grid.component';


@NgModule({
  declarations: [
    GridComponent
  ],
  imports: [
    CommonModule,
    GridviewRoutingModule,
    BrowserModule
  ]
})
export class GridviewModule { }
