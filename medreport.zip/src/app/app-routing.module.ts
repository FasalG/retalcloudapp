import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TableviewComponent } from './tableview/tableview.component';

const routes: Routes = [
  {path:'', redirectTo:'tableview', pathMatch:'full'},
  {path:'tableview',component:TableviewComponent},
  {path:'gridview', loadChildren: () =>import('./gridview/gridview-routing.module').then(m => m.GridviewRoutingModule)},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
